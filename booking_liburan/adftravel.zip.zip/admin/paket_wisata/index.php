<?php
session_start();

require_once __DIR__ . "/../../config/koneksi.php";

// Cek hak akses admin
if (
    !isset($_SESSION['login']) ||
    !isset($_SESSION['role']) ||
    $_SESSION['role'] !== 'admin'
) {
    header("Location: ../../login/login.php");
    exit;
}

// Ambil data paket wisata
$query = mysqli_query(
    $conn,
    "SELECT * FROM paket_wisata ORDER BY id_paket ASC"
);

if (!$query) {
    die("Gagal mengambil data paket wisata: " . mysqli_error($conn));
}

// Pengaturan layout admin
$halamanAktif = 'paket';
$judulHalaman = 'Kelola Paket Wisata';
$namaAdmin = $_SESSION['nama'] ?? 'Admin';

include __DIR__ . '/../partials/header.php';
?>

<style>
    .gambar-paket {
        width: 90px;
        height: 65px;
        object-fit: cover;
        border-radius: 8px;
    }

    .deskripsi-paket {
        min-width: 200px;
        max-width: 300px;
    }

    #tabelPaket thead th {
        white-space: nowrap;
        vertical-align: middle;
    }

    #tabelPaket tbody td {
        vertical-align: middle;
    }

    .dataTables_wrapper {
        padding-top: 5px;
    }
</style>

<div class="d-flex flex-wrap justify-content-between
            align-items-center gap-3 mb-4">

    <div>
        <h2 class="fw-bold mb-1">Kelola Paket Wisata</h2>
        <p class="text-muted mb-0">
            Cari, urutkan, dan kelola data paket wisata.
        </p>
    </div>

    <div class="d-flex flex-wrap gap-2">
        <a href="tambah.php" class="btn btn-primary">
            + Tambah Paket Wisata
        </a>
    </div>

</div>

<div class="card shadow-sm border-0">
    <div class="card-body p-3 p-md-4">

        <div class="table-responsive">
            <table id="tabelPaket"
                class="table table-bordered table-hover table-striped
                       align-middle w-100">

                <thead class="table-primary">
                    <tr>
                        <th>No.</th>
                        <th>Gambar</th>
                        <th>Nama Paket</th>
                        <th>Destinasi</th>
                        <th>Durasi</th>
                        <th>Harga</th>
                        <th>Deskripsi</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>

                <tbody>
                    <?php
                    $no = 1;

                    while ($data = mysqli_fetch_assoc($query)):
                    ?>
                        <tr>
                            <td><?= $no++; ?></td>

                            <td>
                                <?php if (!empty($data['gambar'])): ?>
                                    <img
                                        src="../../uploads/paket_wisata/<?= htmlspecialchars($data['gambar']); ?>"
                                        alt="<?= htmlspecialchars($data['nama_paket']); ?>"
                                        class="gambar-paket">
                                <?php else: ?>
                                    <span class="text-muted">
                                        Tidak ada gambar
                                    </span>
                                <?php endif; ?>
                            </td>

                            <td class="fw-semibold">
                                <?= htmlspecialchars($data['nama_paket']); ?>
                            </td>

                            <td>
                                <?= htmlspecialchars($data['destinasi']); ?>
                            </td>

                            <td class="text-nowrap">
                                <?= (int) $data['durasi']; ?> Hari
                            </td>

                            <td class="text-nowrap">
                                Rp <?= number_format(
                                        (float) $data['harga'],
                                        0,
                                        ',',
                                        '.'
                                    ); ?>
                            </td>

                            <td class="deskripsi-paket">
                                <?= htmlspecialchars($data['deskripsi']); ?>
                            </td>

                            <td>
                                <?php if ($data['status'] === 'Aktif'): ?>
                                    <span class="badge text-bg-success">
                                        Aktif
                                    </span>
                                <?php else: ?>
                                    <span class="badge text-bg-secondary">
                                        <?= htmlspecialchars($data['status']); ?>
                                    </span>
                                <?php endif; ?>
                            </td>

                            <td class="text-nowrap">

                                <a
                                    href="detail.php?id=<?= (int) $data['id_paket']; ?>"
                                    class="btn btn-info btn-sm mb-1 text-white">
                                    <i class="bi bi-eye"></i>
                                    Detail
                                </a>

                                <a
                                    href="edit.php?id=<?= (int) $data['id_paket']; ?>"
                                    class="btn btn-warning btn-sm mb-1">
                                    <i class="bi bi-pencil-square"></i>
                                    Edit
                                </a>

                                <a
                                    href="hapus.php?id=<?= (int) $data['id_paket']; ?>"
                                    class="btn btn-danger btn-sm mb-1"
                                    onclick="return konfirmasiHapus(event, this);">

                                    <i class="bi bi-trash"></i>
                                    Hapus

                                </a>

                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>

            </table>
        </div>

    </div>
</div>

<!-- jQuery dan DataTables -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.datatables.net/2.3.4/js/dataTables.min.js"></script>
<script src="https://cdn.datatables.net/2.3.4/js/dataTables.bootstrap5.min.js"></script>

<script>
    $(document).ready(function() {
        $('#tabelPaket').DataTable({
            pageLength: 5,
            lengthMenu: [5, 10, 25, 50],
            order: [],
            columnDefs: [{
                targets: [1, 8],
                orderable: false
            }],
            language: {
                search: "Cari:",
                lengthMenu: "Tampilkan _MENU_ data",
                info: "Menampilkan _START_ sampai _END_ dari _TOTAL_ data",
                infoEmpty: "Tidak ada data yang ditampilkan",
                infoFiltered: "(difilter dari _MAX_ total data)",
                zeroRecords: "Data yang dicari tidak ditemukan",
                emptyTable: "Belum ada data paket wisata",
                paginate: {}
            }
        });
    });
</script>

<script>
function konfirmasiHapus(event, tombol) {

    event.preventDefault();

    const urlHapus = tombol.getAttribute('href');

    Swal.fire({
        title: 'Hapus Paket Wisata?',
        text: 'Apakah kamu yakin ingin menghapus paket wisata ini?',
        icon: 'warning',

        showCancelButton: true,

        confirmButtonColor: '#dc3545',
        cancelButtonColor: '#6c757d',

        confirmButtonText: 'Ya, Hapus',
        cancelButtonText: 'Batal',

        reverseButtons: true
    }).then((result) => {

        if (result.isConfirmed) {
            window.location.href = urlHapus;
        }

    });

    return false;
}
</script>
<?php include __DIR__ . '/../partials/footer.php'; ?>